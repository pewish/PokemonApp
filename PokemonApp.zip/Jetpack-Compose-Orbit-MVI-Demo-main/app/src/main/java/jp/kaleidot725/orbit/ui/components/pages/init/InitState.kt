package jp.kaleidot725.orbit.ui.components.pages.init

import jp.kaleidot725.orbit.ui.common.UiStatus

data class InitState(
    val status: UiStatus? = null
)
