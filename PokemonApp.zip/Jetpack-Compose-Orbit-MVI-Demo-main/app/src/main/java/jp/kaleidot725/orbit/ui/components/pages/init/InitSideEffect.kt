package jp.kaleidot725.orbit.ui.components.pages.init

sealed class InitSideEffect {
    object Completed : InitSideEffect()
}
