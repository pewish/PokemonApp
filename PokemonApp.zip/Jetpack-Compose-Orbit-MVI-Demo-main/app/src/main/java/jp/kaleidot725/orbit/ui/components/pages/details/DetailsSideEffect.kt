package jp.kaleidot725.orbit.ui.components.pages.details

sealed class DetailsSideEffect {
    object Back : DetailsSideEffect()
}
